from flask import Flask, render_template


#create the object of Flask
app  = Flask(__name__)



#creating our routes
@app.route('/')
def index():
    data = "Codeloop"
    return render_template('index.html', data = data)



#contact routes
@app.route('/contact')
def Contact():
    return render_template('contact.html')





#run flask app
if __name__ == "__main__":
    app.run(debug=True)